package com.academy.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademyPortalApplication {

    public static void main(String[] args) {
        SpringApplication.run(AcademyPortalApplication.class, args);
    }
}
